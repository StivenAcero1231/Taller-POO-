/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p3;

import javax.swing.JOptionPane;

/**
 *
 * @author Acer
 */
public class cels implements Itemp {
    //se implementa el metodo conversor de la interface ITemperatura
    public void conver() {
        double k, f, c;
        c = Double.parseDouble(JOptionPane.showInputDialog("Digite grados celcius"));
        k = c + 273.15;
        f = ((9 * c) / 5) + 32;
        JOptionPane.showMessageDialog(null, "Celcius: "+c+"\nkelvin: "+k+"\nFahrenheid: "+f);
    }

}
