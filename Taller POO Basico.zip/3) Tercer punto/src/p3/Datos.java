/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p3;

import javax.swing.JOptionPane;

/**
 *
 * @author Acer
 */
public class Datos {
    public static void menu(){
        //creacion de varibles 
        int opc;
        opc = Integer.parseInt(JOptionPane.showInputDialog("Unidad de temperatura a  convertir\n1.Grados Celsius \n2.Grados Kelvin \n3.Grados Fahrenheid"));
        //crseacion de objetos
        cels c = new cels();
        Kelv k = new Kelv();
        Farh f = new Farh();
        switch (opc) {
            case 1:
                c.conver();
                break;
            case 2:
                k.conver();
                break;
            case 3:
                f.conver();
                break;
        }
    }
}
