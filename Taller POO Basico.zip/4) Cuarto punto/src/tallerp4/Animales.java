/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tallerp4;

import javax.swing.JOptionPane;

/**
 *
 * @author Personal
 */
public class Animales {
    public String especie;
    public String  pelaje;
    public String habitad;
    public void Alimento(){
        JOptionPane.showMessageDialog(null,"Ninguno");
    }
}
